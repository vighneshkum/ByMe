# UiPathCoreFramework v1.1

An enhanced version of the UiPathCoreFramework which now provides better performance and stability.

What's New :

* Integrated Testing Available.

  * Unit Test Cases written for each block of the framework.

  * Unit Test Template Available for developers to write their own unit  test cases.

  * Validates each unit test case before running.

  * Has the ability to validate different types of result (i.e. string, decimal, integer).

  * Provides consolidated results in a text file.

  * Provides exception for nested workflows.

* New Resuable Components available.

  * Encryption and Decryption Utility available to protect PHI.

  * SetSecure key Utility helps in creating and storing the key as credential in orchestrator.

  * Easy to integrate and use.

* Exception Handling with Classification of Errors.