### Sample Json's

This folder contains the sample JSON's file for Directory Structure and CopyJSON. 