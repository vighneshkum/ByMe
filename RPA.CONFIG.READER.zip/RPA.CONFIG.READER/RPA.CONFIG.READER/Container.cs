﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    [XmlType("Container")]
    public class Container
    {
        public Container()
        {
            this.Components = new List<GCObject>();
        }

        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("Object")]
        public List<GCObject> Components { get; set; }
        public GCObject this[string name]
        {
            get
            {
                foreach (GCObject component in this.Components)
                {
                    if (component.Name.Equals(name))
                        return component;
                }
                return (GCObject)null;
            }
        }
    }
}
