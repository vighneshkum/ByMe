﻿using OpenSpan.Automation;
using OpenSpan.Controls;
using OpenSpan.Design;
using OpenSpan.Runtime;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    public class ConfigurationManager : Component
    {
        private string _fileName = "";
        private bool _onlyForGC = true;
        private bool _configLoaded;
        private IContainer _components;
        private Configuration _configuration;
        private bool _initializeOnProjectStart;
        private bool _applyOnProjectStart;
        private bool _skipEmpty;
        private Logs _logs;
        public string FileName
        {
            get { return this._fileName; }
            set { this._fileName = value; }
        }
        public bool ApplyOnProjectStart
        {
            get { return this._applyOnProjectStart; }
            set { this._applyOnProjectStart = value; }
        }
        public bool InitializeOnProjectStart
        {
            get { return this._initializeOnProjectStart; }
            set { this._initializeOnProjectStart = value; }
        }
        public bool SkipEmpty
        {
            get { return this._skipEmpty; }
            set { this._skipEmpty = value; }
        }
        public int LoadedProjectCount
        {
            get { return RuntimeHost.LoadedProjects.Count; }
        }
        public string ConfigSettings
        {
            get
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(Configuration));
                StringWriter stringWriter1 = new StringWriter();
                StringWriter stringWriter2 = stringWriter1;
                Configuration configuration = this._configuration;
                xmlSerializer.Serialize((TextWriter)stringWriter2, (object)configuration);
                return stringWriter1.ToString();
            }
        }
        public bool IsOnlyForGlobalContainer
        {
            get { return this._onlyForGC; }
            set { this._onlyForGC = value; }
        }
        public Logs Logs
        {
            get { return this._logs; }
            set { this._logs = value; }
        }
        public ConfigurationManager()
        {
            this.InitializeComponent();
        }
        public ConfigurationManager(IContainer container)
        {
            container.Add((IComponent)this);
            this.InitializeComponent();
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing && this._components != null)
                this._components.Dispose();

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._configLoaded = false;
            this._components = (IContainer)new System.ComponentModel.Container();
            this.Logs = new Logs();
            if (string.IsNullOrWhiteSpace(this._fileName))
                this._fileName = RuntimeHost.GetProjectPath() + "\\robot.config";
            if (this._initializeOnProjectStart)
                this.Initialize(this._fileName);
            if (!this._applyOnProjectStart)
                return;
            string[] errorsList;
            this.ApplyConfig(out errorsList);
        }
        public void OpenSpanLogging(bool enable)
        {
            LogController logController = new LogController();
            if (enable)
                logController.TurnFilePublisherOn();
            else
                logController.TurnFilePublisherOff();
        }
        public void RaiseCompleted(Automator automator)
        {
            automator.Complete();
        }
        public void RaiseLaunch(Automator automator)
        {
            automator.Launch();
        }
        private void LoadXml(string fileName)
        {
            if (!File.Exists(fileName))
                return;
            this._fileName = fileName;
            using (StreamReader streamReader = new StreamReader(fileName))
            {
                this._configuration = (Configuration)new XmlSerializer(typeof(Configuration)).Deserialize((TextReader)streamReader);
                streamReader.Close();
                if (this._configuration.RobotSettings.Projects.Count == 0)
                {
                    this._configLoaded = false;
                    return;
                }
            }
            this._configLoaded = true;
        }
        private void AddLog(string logInfo)
        {
            this.AddLog(Logs.LogType.Info, "", logInfo);
        }
        private void AddLog(string methodName, string logInfo)
        {
            this.AddLog(Logs.LogType.Info, methodName, logInfo);
        }
        private void AddLog(Logs.LogType logtype, string logInfo)
        {
            this.AddLog(logtype, "", logInfo);
        }
        private void AddLog(Logs.LogType logtype, string methodName, string logInfo)
        {
            this.AddLog(logtype, methodName, logInfo);
        }
        private void ApplyConfigValues(string projectName, bool skipType, out string[] errorsList)
        {
            List<string> stringList = new List<string>();
            if (RuntimeHost.LoadedProjects.Count == 0)
            {
                //this.AddLog(Logs.LogType.Error, nameof(ApplyConfigValues), "Could not find any project loaded");
                stringList.Add("Could not find any project loaded");
            }
            using (IEnumerator<IRuntimeProject> enumerator1 = ((IEnumerable<IRuntimeProject>)RuntimeHost.LoadedProjects).GetEnumerator())
            {
                while (((IEnumerator)enumerator1).MoveNext())
                {
                    IRuntimeProject current1 = enumerator1.Current;
                    //this.AddLog(Logs.LogType.Debug, nameof(ApplyConfigValues), "Project: " + current1.Name + " Loaded");
                    if (current1.Name == projectName || projectName == "*")
                    {
                        Project project = this._configuration[current1.Name];
                        if (project != null)
                        {
                            //this.AddLog(Logs.LogType.Debug, nameof(ApplyConfigValues), "Project: " + current1.Name + " configuration started");
                            using (IEnumerator<IDesignComponent> enumerator2 = ((IEnumerable<IDesignComponent>)current1.DesignComponents).GetEnumerator())
                            {
                                while (((IEnumerator)enumerator2).MoveNext())
                                {
                                    IDesignComponent current2 = enumerator2.Current;
                                    Container container = project[current2.Name];
                                    if (container != null && (current2 is GlobalContainer || !this._onlyForGC))
                                    {
                                        //this.AddLog(Logs.LogType.Debug, nameof(ApplyConfigValues), "Project item: " + container.Name + " in Project: " + current1.Name + " configuration started");
                                        foreach (FieldInfo field in ((object)current2).GetType().GetFields())
                                        {
                                            GCObject gcObject = container[field.Name];
                                            if (gcObject != null)
                                            {
                                                //this.AddLog(Logs.LogType.Debug, nameof(ApplyConfigValues), "object present in Config: " + gcObject.Name + " project item: " + container.Name + " in Project: " + current1.Name + " configuration started");
                                                object obj = field.GetValue((object)current2);
                                                foreach (Property property1 in gcObject.Properties)
                                                {
                                                    try
                                                    {
                                                        //this.AddLog(Logs.LogType.Debug, nameof(ApplyConfigValues), " object name: " + field.Name + ", property: " + property1.Name + ", Value: " + property1.Value);
                                                        if (string.IsNullOrWhiteSpace(property1.Value) && !this._skipEmpty)
                                                        {
                                                            //this.AddLog(Logs.LogType.Info, nameof(ApplyConfigValues), "Empty value Skipped for property: " + property1.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' object: '" + current2.Name + "'");
                                                        }
                                                        else
                                                        {
                                                            PropertyInfo property2 = obj.GetType().GetProperty(property1.Name);
                                                            if (property2 == (PropertyInfo)null)
                                                            {
                                                                ConnectableVariable connectableVariable = obj as ConnectableVariable;
                                                                if (connectableVariable != null)
                                                                {
                                                                    ((ConnectableHost)connectableVariable).SetPropertyValue(property1.Name, (object)property1.Value, "Configuration");
                                                                    //this.AddLog(Logs.LogType.Info, nameof(ApplyConfigValues), "Value updated for connectable variable - property: " + property1.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' object: '" + current2.Name + "'");
                                                                }
                                                                else
                                                                {
                                                                    Pause pause = obj as Pause;
                                                                    if (pause != null)
                                                                    {
                                                                        int result = 1000;
                                                                        int.TryParse(property1.Value, out result);
                                                                        if (result >= 0)
                                                                        {
                                                                            pause.Milliseconds = result;
                                                                        }
                                                                        else
                                                                        {
                                                                            //this.AddLog(Logs.LogType.Error, nameof(ApplyConfigValues), "Invalied Value, Object- property: " + property1.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' object: '" + current2.Name + "'");
                                                                            stringList.Add(property1.Name + " Invalid Value for Pause : " + property1.Value);
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        string str = "Properties of " + gcObject.Name + " are : ";
                                                                        foreach (PropertyInfo property3 in obj.GetType().GetProperties())
                                                                            str = str + " - " + property3.Name;

                                                                        //this.AddLog(Logs.LogType.Error, nameof(ApplyConfigValues), "Could not found, Object- property: " + property1.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' of type " + obj.GetType().ToString() + " in '" + current2.Name + "'. " + str);
                                                                        stringList.Add(property1.Name + " property could not found in " + gcObject.Name);
                                                                    }
                                                                }
                                                            }
                                                            else if (!property2.CanWrite)
                                                            {
                                                                //this.AddLog(Logs.LogType.Error, nameof(ApplyConfigValues), "Property could not be overwriten, Object- property: " + property2.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' object: '" + current2.Name + "'");
                                                                stringList.Add(property1.Name + " property could not found in " + gcObject.Name);
                                                            }
                                                            else
                                                            {
                                                                //this.AddLog(Logs.LogType.Info, nameof(ApplyConfigValues), "Value updated - property: " + property2.Name + ", Value: '" + property1.Value + "', feild: '" + field.Name + "' object: '" + current2.Name + "'");
                                                                property2.SetValue(obj, Convert.ChangeType((object)property1.Value, property2.PropertyType), (object[])null);
                                                            }
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        //this.AddLog(Logs.LogType.Error, "ApplyConfigValues", "Error: " + ex.Message + "; " + ex.StackTrace + " while processing " + property1.Name + " for value: " + property1.Value + " for Object: " + gcObject.Name + " project item: " + container.Name + " in project " + current1.Name + " Configuration started");
                                                        stringList.Add("Error: " + ex.Message + " ; " + ex.StackTrace + " while processing " + property1.Name + " for object: " + gcObject.Name + " project item: " + container.Name + " in project " + current1.Name + " configuration started");
                                                    }
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            errorsList = stringList.ToArray();
        }
        public bool Initialize()
        {
            if (string.IsNullOrWhiteSpace(this._fileName))
                this._fileName = Path.GetDirectoryName(RuntimeHost.GetDeploymentPackagePath()) + "\\robot.config";

            return this.Initialize(this._fileName);
        }
        public bool Initialize(string fileName)
        {
            this.LoadXml(fileName);
            return this._configLoaded;
        }
        public void ApplyConfig(out string[] errorsList)
        {
            this.ApplyConfigForProject("*", this.SkipEmpty, out errorsList);
        }
        public void ApplyConfig(bool skipEmpty, out string[] errorsList)
        {
            this.ApplyConfigForProject("*", skipEmpty, out errorsList);
        }
        public void ApplyConfigForProject(string projectName, out string[] errorsList)
        {
            this.ApplyConfigForProject(projectName, this._skipEmpty, out errorsList);
        }
        public void ApplyConfigForProject(string projectName, bool skipEmpty, out string[] errorsList)
        {
            if (string.IsNullOrWhiteSpace(this._fileName))
                this._fileName = Path.GetDirectoryName(RuntimeHost.GetDeploymentPackagePath()) + "\\robot.config";
            if (!this._configLoaded)
                this.Initialize(this._fileName);
            if (!this._configLoaded)
                throw new FileNotFoundException("Configuration file could not be loaded");

            this.ApplyConfigValues(projectName, skipEmpty, out errorsList);
        }
        public void ApplyConfigFromFile(string fileName, out string[] errorsList)
        {
            this.ApplyConfigFromFile(fileName, "*", out errorsList);
        }
        public void ApplyConfigFromFile(string fileName, string projectName, out string[] errorsList)
        {
            this.ApplyConfigFromFile(fileName, projectName, this._skipEmpty, out errorsList);
        }
        public void ApplyConfigFromFile(string fileName, string projectName, bool skipEmpty, out string[] errorsList)
        {
            this.Initialize(fileName);
            this.ApplyConfigForProject(projectName, skipEmpty, out errorsList);
        }
        public string GetConfigValue(string projectName, string projectItem, string objectItem, string propertName)
        {
            string str = (string)null;
            if (this._configuration != null)
            {
                Project project = this._configuration[projectName];
                if (project != null)
                {
                    Container container = project[projectItem];
                    if (container != null)
                    {
                        GCObject gcObject = container[objectItem];
                        if (gcObject != null)
                        {
                            Property property = gcObject[propertName];
                            if (property != null)
                                str = property.Value;
                        }
                    }
                }
            }
            return str;
        }

        #endregion
    }
}
