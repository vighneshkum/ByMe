﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    public class RobotSettings
    {
        public RobotSettings()
        {
            this.Projects = new List<Project>();
        }
        [XmlElement("Project")]
        public List<Project> Projects { get; set; }
        public Project this[string name]
        {
            get
            {
                foreach (Project project in this.Projects)
                {
                    if (project.Name.Equals(name))
                        return project;
                }
                return (Project)null;
            }

        }
    }
}
