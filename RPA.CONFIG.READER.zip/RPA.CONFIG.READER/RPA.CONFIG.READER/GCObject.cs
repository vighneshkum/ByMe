﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    [XmlType("Object")]
    public class GCObject
    {
        public GCObject()
        {
            this.Properties = new List<Property>();
        }
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("Property")]
        public List<Property> Properties { get; set; }
        public Property this[string name]
        {
            get
            {
                foreach (Property property in this.Properties)
                {
                    if (property.Name.Equals(name))
                        return property;
                }
                return (Property)null;
            }
        }
    }
}
