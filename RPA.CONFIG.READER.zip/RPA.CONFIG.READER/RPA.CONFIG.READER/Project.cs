﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    [XmlType("Project")]
    public class Project
    {
        public Project()
        {
            this.ProjectItems = new List<Container>();
        }
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlElement("Container")]
        public List<Container> ProjectItems { get; set; }
        public Container this[string name]
        {
            get
            {
                foreach (Container projectItem in this.ProjectItems)
                {
                    if (projectItem.Name.Equals(name))
                        return projectItem;

                }
                return (Container)null;
            }
        }
    }
}
