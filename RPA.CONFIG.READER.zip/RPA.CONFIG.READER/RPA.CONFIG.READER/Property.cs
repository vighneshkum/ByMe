﻿using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    [XmlType("Property")]
    public class Property
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("value")]
        public string Value { get; set; }
    }
}
