﻿using System.Xml.Serialization;

namespace RPA.CONFIG.READER
{
    [XmlType("Configuration")]
    public class Configuration
    {
        public Configuration()
        {
            this.RobotSettings = new RobotSettings();
        }
        [XmlElement("RobotSettings")]
        public RobotSettings RobotSettings { get; set; }
        public Project this[string name]
        {
            get
            {
                return this.RobotSettings[name];
            }
        }
    }
}
