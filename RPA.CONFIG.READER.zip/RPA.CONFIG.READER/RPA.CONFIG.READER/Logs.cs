﻿using System;
using System.Collections.Generic;

namespace RPA.CONFIG.READER
{
    public class Logs
    {
        private List<string> _debugLogs;
        private List<string> _infoLogs;
        private List<string> _errorLogs;
        public List<string> this[Logs.LogType logtype]
        {
            get
            {
                if (logtype == Logs.LogType.Any)
                    return this["Any"];
                return this[logtype.ToString()];
            }
        }
        public List<string> this[string logType]
        {
            get
            {
                if (logType.ToUpper().Equals("ERROR"))
                    return this._errorLogs;
                if (logType.ToUpper().Equals("INFO"))
                    return this._infoLogs;
                if (logType.ToUpper().Equals("DEBUG"))
                    return this._debugLogs;

                List<string> stringList = new List<string>();
                stringList.AddRange((IEnumerable<string>)this._errorLogs);
                stringList.AddRange((IEnumerable<string>)this._infoLogs);
                stringList.AddRange((IEnumerable<string>)this._debugLogs);
                return stringList;
            }
        }
        public Logs()
        {
            this._debugLogs = new List<string>();
            this._infoLogs = new List<string>();
            this._errorLogs = new List<string>();
        }
        public void AddLog(Logs.LogType type, string source, string data)
        {
            if (type == Logs.LogType.Error)
                this._errorLogs.Add(DateTime.UtcNow.ToString() + "\t\t" + source + "\t\t" + data);
            if (type == Logs.LogType.Debug)
                this._debugLogs.Add(DateTime.UtcNow.ToString() + "\t\t" + source + "\t\t" + data);
            if (type == Logs.LogType.Info)
                this._infoLogs.Add(DateTime.UtcNow.ToString() + "\t\t" + source + "\t\t" + data);
        }
        public enum LogType
        {
            Debug,
            Info,
            Error,
            Any,
        }
    }
}
